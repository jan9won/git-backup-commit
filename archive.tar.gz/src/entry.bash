#!/usr/bin/env bash

# --------------------------------------------------------------------------- #
# Args
# --------------------------------------------------------------------------- #

# [command]
# [command option]

# [global option]

# --------------------------------------------------------------------------- #
# Get entry script's absolute path
# --------------------------------------------------------------------------- #

get_script_path () {
	local SCRIPT_PATH
	local SOURCE=${BASH_SOURCE[0]}
	while [ -L "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
		SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )
		SOURCE=$(readlink "$SOURCE")
		[[ $SOURCE != /* ]] && SOURCE=$SCRIPT_PATH/$SOURCE # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
	done
	SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )
	return $SCRIPT_PATH
}

SCRIPT_PATH=get_script_path

# --------------------------------------------------------------------------- #
# Check if we're inside a git repository
# --------------------------------------------------------------------------- #

IS_GIT_REPO=$(git rev-parse --is-inside-work-tree 2>/dev/null)

if [[ ! $IS_GIT_REPO = "true" ]]; then
	exit 1
fi

# --------------------------------------------------------------------------- #
# Is remote for backup set in local config file?
# --------------------------------------------------------------------------- #

BACKUP_REMOTE_NAME=$(git config --get git-backup.remote-name)
REMOTES=($(git remote))
NUMBER_OF_REMOTES=${#REMOTES[@]}

if [[ $NUMBER_OF_REMOTES = 0 ]]; then
	printf "No remote repository set yet.\n"
	exit 1
fi

if [[ -z $BACKUP_REMOTE_NAME ]]; then
	printf "Backup remote's name is not configured in git config.\n"
	printf "Enter one of your remote's name to use it for backup ["
	for i in "${!REMOTES[@]}"; do
		printf "${REMOTES[$i]}";
		if (( $NUMBER_OF_REMOTES > $i + 1 )); then
			printf " / "
		fi
	done
	printf "] : "
	read BACKUP_REMOTE_NAME
fi

# Does this remote actually exists?
does_remote_exist(){
	local REMOTE=$1
	local EXISTS=false
	for remote in ${REMOTES[@]}; do
		[[ $remote = $BACKUP_REMOTE_NAME ]] && EXISTS=true
	done
	retrun $EXISTS
}
does_remote_exist

# --------------------------------------------------------------------------- #
# create parallel arrays of valid short/long arguments
# --------------------------------------------------------------------------- #

# Define pairs of options.
VALID_OPT_PAIRS=(
	"-h,--help"
	"-r,--remote,true"
	"-t"
)

parse_valid_opt_pairs(){
	VALID_ARGS_SHORT=()
	VALID_ARGS_LONG=()
	OPTSTRING=""
	VALID_ARGS_LENGTH=${#VALID_OPT_PAIRS[@]}
	for VALID_ARG_PAIR in ${VALID_OPT_PAIRS[@]}; do
		local IFS=","
		ARG_PAIR=($VALID_ARG_PAIR)
		VALID_ARGS_SHORT+=(${ARG_PAIR[0]})
		VALID_ARGS_LONG+=(${ARG_PAIR[1]})
		OPTSTRING+=${ARG_PAIR[0]:1}
		if [[ ${ARG_PAIR[2]} = "true" ]]; then
			OPTSTRING+=":"
		fi
	done
}

parse_valid_opt_pairs; echo $OPTSTRING

# --------------------------------------------------------------------------- #
# substitute long arguments with short ones
# --------------------------------------------------------------------------- #

for arg in "$@"; do
	for i in $(seq 0 $VALID_ARGS_LENGTH); do
		if [[ $arg = ${VALID_ARGS_LONG[$i]} ]]; then
			shift
			set -- "$@" ${VALID_ARGS_SHORT[$i]}
		fi
	done
done

# --------------------------------------------------------------------------- #
# call feature scripts for each options and arguments
# --------------------------------------------------------------------------- #

while getopts $OPTSTRING opt
do
	case $opt in
		push)
			$SCRIPT_PATH/features/push.bash;;
		fetch) 
			$SCRIPT_PATH/features/fetch.bash;; 
		restore) 
			$SCRIPT_PATH/features/restore.bash;; 
		prune) 
			$SCRIPT_PATH/features/prune.bash;; 
		*) 
			$SCRIPT_PATH/features/usage.bash;; 
	esac 
done