#!/usr/bin/env bash

echo "usage: git backup [push/fetch/restore/prune]"
