#!/usr/bin/env bash
# echo "delete.bash: $@"

# git push <remote> --delete <tag-name>
