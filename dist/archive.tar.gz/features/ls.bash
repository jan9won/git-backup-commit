#!/usr/bin/env bash

# PREFIX=$(git config --get jan9wongit-wip-commit.prefix)
# git branch -a --sort=authordate --list "$PREFIX/*"
