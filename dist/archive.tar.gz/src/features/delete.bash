#!/usr/bin/env bash
echo "delete.bash: $@"
