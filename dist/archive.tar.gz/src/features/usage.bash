#!/usr/bin/env bash
echo $@
empty="
usage       git backup <command> [flags]

<command>
create          create new backup branch, commit everything and restore working directory
delete          delete given backup branch and its commit
restore         restore working directory from given backup branch
ls              list all backup branches
push            push backup branches to configured backup remote
fetch           fetch backup branches to configured backup remote

[flags]
--help          print help for a given command

"

create="
usage           git backup create [flags]

description
1. create new backup branch
2. commit everything
3. restore working directory

[flags]
--force         create backup even if there's nothing to add or commit.

"

ls="
usage           git backup ls [flags]

[flags]
-r | --remote   show remote
-a | --all      show remote and local

"

while [[ "$#" > 0 ]]; do
	case $1 in
		create)
			printf "$create"
			exit 0;
		;;
		ls)
			printf "$ls"
			exit 0;
		;;
		-*)
			echo "illegal option $1";
			shift;
			;;
		*)
			echo "illegal command $1"
			shift;
			;;
	esac
done

printf "$empty"
