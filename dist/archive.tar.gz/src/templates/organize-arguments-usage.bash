SOURCE=${BASH_SOURCE[0]}
while [ -L "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
	SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )
	SOURCE=$(readlink "$SOURCE")
	[[ $SOURCE != /* ]] && SOURCE=$SCRIPT_PATH/$SOURCE # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )

OPT_CONFIG="
	-o, --long-opt, true
"
IFS_DEFAULT=$IFS
IFS=$'\n'
ORG_OPT_RESULT=($("$SCRIPT_PATH/path/to/organize-arguments.bash" "$OPT_CONFIG" $@))
IFS=$IFS_DEFAULT

OPTSTRING=${ORG_OPT_RESULT[0]}
USEFUL_OPTS=${ORG_OPT_RESULT[1]}
REST_OPTS=${ORG_OPT_RESULT[2]}
REST_ARGS=${ORG_OPT_RESULT[3]}

echo $OPTSTRING
echo $USEFUL_OPTS
echo $REST_OPTS
echo $REST_ARGS