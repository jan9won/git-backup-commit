
ARGS_TO_PASS=("$@")

while [[ "$#" > 0 ]]; do
	case $1 in
		-o|--options)
			shift;
			# do something
			exit 0;
			;;
		plain-args)
			shift;
			# do something
			exit 0;
			;;
		-*)
			echo "illegal option $1";
			shift;
			;;
		*)
			echo "illegal command $1"
			shift;
			;;
	esac
done