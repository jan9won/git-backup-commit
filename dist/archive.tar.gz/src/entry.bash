#!/usr/bin/env bash

# --------------------------------------------------------------------------- #
# resolve script path
# --------------------------------------------------------------------------- #

SOURCE="${BASH_SOURCE[0]}"
while [ -L "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
	SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )
	SOURCE=$(readlink "$SOURCE")
	[[ $SOURCE != /* ]] && SOURCE=$SCRIPT_PATH/$SOURCE # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_PATH=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )

# --------------------------------------------------------------------------- #
# Check if we're inside a git repository
# --------------------------------------------------------------------------- #

IS_GIT_REPO=$(git rev-parse --is-inside-work-tree 2>/dev/null)

if [[ ! $IS_GIT_REPO = "true" ]]; then
	printf "You're not in a git repository.\n"
	exit 1
fi

# --------------------------------------------------------------------------- #
# prepare branch prefix
# --------------------------------------------------------------------------- #

$SCRIPT_PATH/utils/prepare-prefix.bash
BACKUP_BRANCH_WAS_SET=$?
if [[ BACKUP_BRANCH_WAS_SET = 3 ]]; then
	exit 0
fi

# --------------------------------------------------------------------------- #
# handle arguments
# --------------------------------------------------------------------------- #

ARGS_TO_PASS=("$@")

while [[ "$#" > 0 ]]; do
	case $1 in
		-h|--help)
			shift;
			$SCRIPT_PATH/features/usage.bash "$@"
			exit 0;
			;;
		create)
			shift;
			$SCRIPT_PATH/features/create.bash "$@"
			exit 0;
			;;
		ls)
			shift;
			$SCRIPT_PATH/features/ls.bash "$@"
			exit 0;
			;;
		push)
			shift;
			$SCRIPT_PATH/features/push.bash "$@"
			exit 0;
			;;
		fetch)
			shift;
			$SCRIPT_PATH/features/fetch.bash "$@"
			exit 0;
			;;
		restore)
			shift;
			$SCRIPT_PATH/features/restore.bash "$@"
			exit 0;
			;;
		delete)
			shift;
			$SCRIPT_PATH/features/delete.bash "$@"
			exit 0;
			;;
		-*)
			echo "illegal option $1";
			shift;
			;;
		*)
			echo "illegal command $1"
			shift;
			;;
	esac
done

$SCRIPT_PATH/features/usage.bash
exit 1;